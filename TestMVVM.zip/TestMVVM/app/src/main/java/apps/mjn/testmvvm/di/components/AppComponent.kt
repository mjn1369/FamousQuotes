package apps.mjn.testmvvm.di.components

import apps.mjn.testmvvm.core.TestMvvmApplication
import apps.mjn.testmvvm.di.modules.AppModule
import apps.mjn.testmvvm.di.modules.ViewModelModule
import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        ViewModelModule::class,
        AppModule::class
    ]
)

interface AppComponent: AndroidInjector<TestMvvmApplication> {

    @Component.Builder
    abstract class Builder: AndroidInjector.Builder<TestMvvmApplication>()
}