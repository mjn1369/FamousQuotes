package apps.mjn.testmvvm.di.modules

import android.content.Context
import apps.mjn.domain.executor.PostExecutionThread
import apps.mjn.domain.executor.UseCaseExecutor
import apps.mjn.testmvvm.core.TestMvvmApplication
import apps.mjn.testmvvm.executor.ExecutorThread
import apps.mjn.testmvvm.executor.UIThread
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class AppModule {

    @Provides
    @Singleton
    fun provideApplicationContext(application: TestMvvmApplication): Context = application.applicationContext

    @Provides
    @Singleton
    fun provideUseCaseExecutor(): UseCaseExecutor = ExecutorThread()

    @Provides
    @Singleton
    fun providePostExecutionThread(): PostExecutionThread = UIThread()

}