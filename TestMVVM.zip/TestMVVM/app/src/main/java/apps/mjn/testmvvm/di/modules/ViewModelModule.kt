package apps.mjn.testmvvm.di.modules

import androidx.lifecycle.ViewModelProvider
import apps.mjn.testmvvm.core.ViewModelFactory
import dagger.Binds
import dagger.Module

@Module
abstract class ViewModelModule {

    @Binds
    internal abstract fun bindViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory

}